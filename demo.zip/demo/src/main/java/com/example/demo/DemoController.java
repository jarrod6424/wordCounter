package com.example.demo;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
public class DemoController {
    private int totalCount = 0;
    private HashMap<Integer,Integer> idMap = new HashMap<Integer, Integer>();

    @RequestMapping(value="/counter")
    public String wordCounter(@RequestParam(defaultValue = "1") int id,
                              @RequestParam(defaultValue = "demo") String message){
        int wordCount = 0;
        String output = "ID " + id + " already exists.";
        String words[] = message.split(" ");

        if(!idMap.containsKey(id)){
            idMap.put(id, 1);
            wordCount = words.length;
            output = "ID = " + id
                + "<br>" + "Message = " + message + "<br>"
                + "<br>" + "Previous Word Count = " + totalCount
                + "<br>" + "Total Word Count = " + (totalCount + wordCount) + ".";
            totalCount += wordCount;
        }else{
            output = "ID " + id + " already exists.";
        }
        
        return output;
    }
}
